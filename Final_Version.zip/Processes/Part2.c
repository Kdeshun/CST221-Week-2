#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <spawn.h>
#include <sys/wait.h>



int main(int argc, char *argv[]) {
    extern char **environ;//Declare the external variable 'environ', which points to an array of strings containing environment variables
    if (argc != 2) //check argument
    {
        fprintf(stderr, "Usage: %s <program_to_spawn>\n", argv[0]);//error message
        return 1;
    }

    pid_t pid;//process id variable
    char *spawn_args[] = {argv[1], NULL};//argument 
    if (posix_spawn(&pid, argv[1], NULL, NULL, spawn_args, environ) != 0) // create Spawed process
    {
        printf("posix_spawn failed\n");//error message
        return 1;
    }

    printf("Spawned process with PID %d\n", pid);//print spawn process id
    int status;
    if (waitpid(pid, &status, 0) == -1) //wait for child process
    {
        printf("Error waitpid\n");
        return 1;
    }
    printf("Process %d finished with status %d\n", pid, status);//print finished process id
    return 0;
}

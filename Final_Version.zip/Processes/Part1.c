#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();//create child process
    if (pid < 0) // if fork call failed
    {
        printf("fork failed\n");// print error message
        return 1;
    }

    if (pid == 0) //Child process section
    {
        for (int i = 0; i < 10; i++) //print 10 time child message
        {
            printf("Child process message %d\n", i + 1);//print message
            sleep(1);//sleep 1 second
        }
        return 0;
    } else //parent process section
    {
        for (int i = 0; i < 10; i++) //print 10 time parent message
        {
            printf("Parent process message %d\n", i + 1);//print message
            sleep(2);//sleep 2 second
        }
        int status;
        waitpid(pid, &status, 0);//wait for child process.
        return 0;
    }
}

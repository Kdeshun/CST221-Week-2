#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#define WAKEUP SIGUSR1

void handle_signal(int sig) {
    // Signal handler for WAKEUP signal
    if (sig == WAKEUP) {
        printf("Child process received WAKEUP signal.\n");
    }
}

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        printf("fork Error\n");
        return 1;
    }

    if (pid == 0) {
        // Child process
        signal(WAKEUP, handle_signal);
        // Suspend execution until a signal is received
        pause();
        for (int i = 0; i < 20; i++) {
            printf("Child process message %d\n", i + 1);//print child message
            sleep(1);
        }
        return 1;
    } else {
        // Parent process
        for (int i = 0; i < 30; i++) {
            if (i == 5) {
                // Send WAKEUP signal to child process
                kill(pid, WAKEUP);
            }
            printf("Parent process message %d\n", i + 1);//print parent message
            sleep(1);
        }
        // Wait for child process to finish
        int status;
        waitpid(pid, &status, 0);
        return 1;
    }
}

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Function for thread 1
void *thread1_func(void *arg) {
    for (int i = 0; i < 10; i++) {
        printf("Thread 1 message %d\n", i + 1);
        sleep(1);  // Sleep for 1 second
    }
    return NULL;
}

// Function for thread 2
void *thread2_func(void *arg) {
    for (int i = 0; i < 10; i++) {
        printf("Thread 2 message %d\n", i + 1);
        sleep(2);  // Sleep for 2 seconds
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Create thread 1
    if (pthread_create(&thread1, NULL, thread1_func, NULL) != 0) {
        printf("Failed to create thread 1\n");//display error message if thread is not created
        return 1;
    }

    // Create thread 2
    if (pthread_create(&thread2, NULL, thread2_func, NULL) != 0) {
        printf("Failed to create thread 2\n");//display error message if thread is not created
        return 1;
    }

    // Wait for thread 1 to finish
    if (pthread_join(thread1, NULL) != 0) {
        printf("Failed to join thread 1\n");//display error message
        return 1;
    }

    // Wait for thread 2 to finish
    if (pthread_join(thread2, NULL) != 0) {
        printf("Failed to join thread 2\n");//display error message
        return 1;
    }

    printf("Both threads have finished.\n");
    return 0;
}

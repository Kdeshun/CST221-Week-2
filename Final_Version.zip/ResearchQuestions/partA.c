/*
Answer:
The above code will not satisfy all the necessary conditions to be a valid mutual exclusion solution 
because, it does not ensure progress as well as bounded waiting This is a just slight modification 
of Peterson algorithm where it doesn’t introduce variable to indicate that the process would like to 
enter critical section and both processes will be stuck in while loops if they both want to enter CS 
at the same time, regardless of TS values.
*/

// correct Solution
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_ITER 5

int turn = 0;  

void* processP0(void* arg) {
    for (int i = 0; i < NUM_ITER; i++) {
        while (turn != 0) {}
        printf("Process P0 in Critical Section\n");
        sleep(1); 
        turn = 1;
        printf("Process P0 in Remainder Section\n");
        sleep(1); 
    }
    return NULL;
}

void* processP1(void* arg) {
    for (int i = 0; i < NUM_ITER; i++) {
        while (turn != 1) {}
        printf("Process P1 in Critical Section\n");
        sleep(1);
        turn = 0;
        printf("Process P1 in Remainder Section\n");
        sleep(1); 
    }
    return NULL;
}

int main() {
    pthread_t t0, t1;

    pthread_create(&t0, NULL, processP0, NULL);
    pthread_create(&t1, NULL, processP1, NULL);

    pthread_join(t0, NULL);
    pthread_join(t1, NULL);

    return 0;
}

//Answer
//The given code creates 3 child processes upon execution
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    printf("Parent process pid %d\n",getpid());
    pid_t pid1 = fork();
    if (pid1 == 0) {
        printf("Child process pid %d\n",getpid());
    }
    
    /*
    P
     \
      C
    */
    pid_t pid2=fork();
    if(pid2==0){
        printf("Child process pid %d\n",getpid());
    }
    /*
     P
    / \
   C   C
        \
         C
    */
    exit(0);
    return 0;
}

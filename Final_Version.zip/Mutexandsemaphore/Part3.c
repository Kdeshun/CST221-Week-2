#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define NUM_TRANSACTIONS 1000000

// Global variable representing bank balance
int bank_balance = 0;
sem_t semaphore;

void* deposit(void* arg) {
    for (int i = 0; i < NUM_TRANSACTIONS; i++) {
        sem_wait(&semaphore);
        bank_balance += 1; // Simulate $1 deposit
        sem_post(&semaphore);
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Initialize the semaphore with a value of 1
    sem_init(&semaphore, 0, 1);

    // Create two threads
    pthread_create(&thread1, NULL, deposit, NULL);
    pthread_create(&thread2, NULL, deposit, NULL);

    // Wait for both threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Print the final bank balance
    printf("Final bank balance: $%d\n", bank_balance);

    // Destroy the semaphore
    sem_destroy(&semaphore);

    return 0;
}

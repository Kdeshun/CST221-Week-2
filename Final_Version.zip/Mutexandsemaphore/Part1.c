#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define NUM_TRANSACTIONS 1000000

// Global variable representing bank balance
int bank_balance = 0;

void* deposit(void* arg) {
    for (int i = 0; i < NUM_TRANSACTIONS; i++) {
        bank_balance += 1; // Simulate $1 deposit
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Create two threads
    pthread_create(&thread1, NULL, deposit, NULL);
    pthread_create(&thread2, NULL, deposit, NULL);

    // Wait for both threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    // Print the final bank balance
    printf("Final bank balance: $%d\n", bank_balance);

    return 0;
}
